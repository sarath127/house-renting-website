<!Doctype html>
<head>
<Title> template </Title>

<link href="template.css" rel="stylesheet" type="text/css">
<link href="layout.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="Holder"> </div>
<div id="TopBar"></div>
<div id="NavBar">
<nav>
<ul>
<li><a href="account.php">VIEW PROFILE</a></li>
<li><a href="upload.php">UPLOAD PROPERTY</a></li>
<li><a href="edit.php">EDIT PROFILE</a></li>
<li><a href="reset.php">RESET PASSWORD</a></li>
<li><a href="logout.php">LOG OUT</a></li>
</ul>
</nav>
</div>
<div id="Filter"></div>
<div id="Content">
  <div id="pageheading">
  <h1> Reset password</h1> 
  </div>
  <div id="Contentl"></div>
</div>
<div id="Footer"></div>
</body>
