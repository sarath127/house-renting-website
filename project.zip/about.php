<!Doctype html>
<head>
<Title>about us</Title>

<link href="template.css" rel="stylesheet" type="text/css">
<link href="layout.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="Holder"> </div>
<div id="TopBar"></div>
<div id="NavBar">
<nav>
<ul>
<li><a href="home.php">home</a></li>
<li><a href="login.php">login</a></li>
<li><a href="register.php">Sign up</a></li>
<li><a href="about.php">About us</a></li>
<li><a href="contact.php">Contact us</a></li>
</ul>
</nav>
</div>
<div id="Filter"></div>
<div id="Content">
<center>
<table width="942" height="304" border="0" align="left">
  <tr>
    <td height="50" colspan="5"><p>this is a online rental house management web application developed by sarath &amp; team</p>
      <p>using PHP &amp; Mysql</p></td>
    </tr>
  <tr>
    <td width="146" height="168">&nbsp;</td>
    <td width="170">&nbsp;</td>
    <td width="220">&nbsp;</td>
    <td width="193">&nbsp;</td>
    <td width="179">&nbsp;</td>
  </tr>
  <tr>
    <td height="71">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</center>
</div>
<div id="Footer"></div>
</body>
