<!Doctype html>
<head>
<Title> template </Title>

<link href="template.css" rel="stylesheet" type="text/css">
<link href="layout.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="Holder"> </div>
<div id="TopBar"></div>
<div id="NavBar">
<nav>
<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="login.php">LOGIN</a></li>
<li><a href="signup.php">SIGN UP</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="contact.php">CONTACT US</a></li>
</ul>
</nav>
</div>
<div id="Filter"></div>
<div id="Content">
  <div id="pageheading">
  <h1> sign up!</h1> 
  </div>
  <div id="Contentl">Content for  id "Contentl" Goes Here</div>
  <div id="Contentr">Content for  id "Contentr" Goes Here</div>
</div>
<div id="Footer"></div>
</body>
