<?php exit(); /* For security reason. To avoid public user downloading below data! */?>
"RecordID"	"Date"	"IP"	"name"	"email address"	"comment"
"20160920-8007"	"2016-09-20 06:28:23"	"::1"	"saraths674@gmail.com"	"saraths674@gmail.com"	"hai da"
"20160920-ba62"	"2016-09-20 06:33:05"	"::1"	"dfasdf"	"saraths674@gmail.com"	"hello"
"20160920-5822"	"2016-09-20 06:33:38"	"::1"	"hai"	"dfasf@fams.com"	"sdfasdf"
"20160920-5823"	"2016-09-20 06:49:00"	"::1"	"sfdadf"	"sfdadf@fssdf.co"	"dsfadf"
"20160920-fa58"	"2016-09-20 07:37:06"	"::1"	"ffsdfasdf"	"fasdf@gmail.com"	"dfasdfasdfa"
"20160920-7186"	"2016-09-20 09:15:06"	"::1"	"adada"	"mmmm@gamil.con"	"mmm"
