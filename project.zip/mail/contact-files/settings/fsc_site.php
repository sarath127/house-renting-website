<?php
//do not allow direct access
if ( strpos(strtolower($_SERVER['SCRIPT_NAME']),strtolower(basename(__FILE__))) ) {
  header('HTTP/1.0 403 Forbidden');
  exit('Forbidden');
}
//**AUTO-GENERATED DATA, DO NOT HAND EDIT!**
//Settings for 'Fast Secure Contact Form' PHP Script
$array = array (
  'site_name' => 'domicile',
  'site_url' => 'http://localhost/home/mail/contact-files',
  'site_path' => 'C:/xampp/htdocs/home/mail/contact-files',
  'admin_name' => 'admin1234',
  'admin_email' => 'domicile892@gmail.com',
  'admin_usr' => 'domicile892@gmail.com',
  'admin_pwd' => 'hashed_c8ad75444a3d23fe04b639a156beb2ad',
  'site_charset' => 'UTF-8',
  'language' => 'en_US',
  'timezone' => 'Asia/Kolkata',
  'pwd_reset_key' => '',
);
?>